package com.example.dicoding_ditonton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
